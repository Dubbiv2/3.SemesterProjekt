from flask import Flask, request, render_template, jsonify, redirect, url_for, session
from datetime import datetime
from functools import wraps
import psycopg2
from psycopg2.extras import RealDictCursor

app = Flask(__name__)
app.secret_key = "1234"  # SKIFT I PRODUKTION


# -------------------------
# DATABASE
# -------------------------
def get_db():
    return psycopg2.connect(
        host="192.168.220.131",
        database="postgres",
        user="postgres",
        password="1234"
    )


# -------------------------
# LOGIN REQUIRED
# -------------------------
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated_function


# -------------------------
# LOGIN
# -------------------------
@app.route("/login", methods=["GET", "POST"])
def login():
    error = None

    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")

        users = {
            "admin": "admin",
            "anemette": "1234"
        }

        if username in users and users[username] == password:
            session["logged_in"] = True
            session["username"] = username
            return redirect(url_for("index"))
        else:
            error = "Forkert brugernavn eller adgangskode"

    return render_template("login.html", error=error)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# -------------------------
# FORSIDE
# -------------------------
@app.route("/")
@login_required
def index():
    return render_template("index.html")


# -------------------------
# OPRET NY PATIENT
# -------------------------
@app.route("/patient/new", methods=["GET", "POST"])
@login_required
def new_patient():
    if request.method == "POST":
        navn = request.form.get("navn")
        alder = request.form.get("alder")
        cpr = request.form.get("cpr")
        diagnose = request.form.get("diagnose")

        if not navn:
            return "Navn er påkrævet", 400

        try:
            conn = get_db()
            with conn.cursor() as cur:
                cur.execute("""
                    INSERT INTO patient (navn, alder, cpr, diagnose)
                    VALUES (%s, %s, %s, %s)
                """, (navn, alder, cpr, diagnose))
                conn.commit()
            conn.close()
        except Exception as e:
            print("Databasefejl:", e)
            return "Databasefejl", 500

        return redirect(url_for("patientdatabase"))

    return render_template("new_patient.html")


# -------------------------
# SLET PATIENT
# -------------------------
@app.route("/patient/delete/<int:patient_id>", methods=["POST"])
@login_required
def delete_patient(patient_id):
    try:
        conn = get_db()
        with conn.cursor() as cur:
            # Slet sensor-data først
            cur.execute(
                "DELETE FROM patient_data WHERE patient_id = %s",
                (patient_id,)
            )

            # Slet patient
            cur.execute(
                "DELETE FROM patient WHERE id = %s",
                (patient_id,)
            )

            conn.commit()
        conn.close()
    except Exception as e:
        print("Databasefejl:", e)
        return "Databasefejl", 500

    return redirect(url_for("patientdatabase"))


# -------------------------
# PATIENTDATABASE
# -------------------------
@app.route("/patientdatabase")
@login_required
def patientdatabase():
    patients = []

    try:
        conn = get_db()
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT id, navn, alder, cpr, diagnose
                FROM patient
                ORDER BY navn
            """)
            patients = cur.fetchall()
        conn.close()
    except Exception as e:
        print("Databasefejl:", e)

    return render_template("patientdatabase.html", patients=patients)


# -------------------------
# PATIENT DETALJE + SENSOR DATA
# -------------------------
@app.route("/patient/<int:patient_id>")
@login_required
def patient_detail(patient_id):
    patient = None
    sensor_data = []

    try:
        conn = get_db()
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT id, navn, alder, cpr, diagnose
                FROM patient
                WHERE id = %s
            """, (patient_id,))
            patient = cur.fetchone()

            cur.execute("""
                SELECT gps_lat, gps_lon, created_at
                FROM patient_data
                WHERE patient_id = %s
                ORDER BY created_at DESC
                LIMIT 20
            """, (patient_id,))
            sensor_data = cur.fetchall()

        conn.close()
    except Exception as e:
        print("Databasefejl:", e)

    return render_template(
        "patient.html",
        patient=patient,
        sensor_data=sensor_data
    )


# -------------------------
# API – SENSOR DATA
# -------------------------
@app.route("/api/update", methods=["POST"])
def api_update():
    data = request.get_json()
    if not data:
        return jsonify({"status": "error", "msg": "no json"}), 400

    patient_id = data.get("patient_id")
    gps_lat = data.get("latitude")
    gps_lon = data.get("longitude")

    if not patient_id:
        return jsonify({"status": "error", "msg": "missing patient_id"}), 400

    try:
        conn = get_db()
        with conn.cursor() as cur:
            cur.execute("""
                INSERT INTO patient_data (patient_id, gps_lat, gps_lon, created_at)
                VALUES (%s, %s, %s, %s)
            """, (patient_id, gps_lat, gps_lon, datetime.now()))
            conn.commit()
        conn.close()
    except Exception as e:
        print("Databasefejl:", e)
        return jsonify({"status": "error"}), 500

    return jsonify({"status": "success"})


# -------------------------
# START SERVER
# -------------------------
if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
